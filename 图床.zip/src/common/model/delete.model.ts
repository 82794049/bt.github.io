/* eslint-disable import/prefer-default-export */
export enum deleteStatusEnum {
  deleted = 'deleted',
  allDeleted = 'allDeleted',
  deleteFail = 'deleteFail'
}
