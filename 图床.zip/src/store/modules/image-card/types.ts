import { UploadedImageModel } from '@/common/model/upload.model'

export interface ImageCardStateTypes {
  imgCardArr: UploadedImageModel[]
}
