import { UserSettingsModel } from '@/common/model/user-settings.model'

export default interface UserSettingsStateTypes {
  userSettings: UserSettingsModel
}
