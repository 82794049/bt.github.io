import { UserConfigInfoModel } from '@/common/model/user-config-info.model'

export default interface UserConfigInfoStateTypes {
  userConfigInfo: UserConfigInfoModel
}
